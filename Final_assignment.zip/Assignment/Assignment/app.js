let submitBtn =document.querySelector("#submitBtn");
let today =document.querySelector("#today");
let upcoming =document.querySelector("#upcoming");
// let completed =document.querySelector("#completed");
let date = new Date().toJSON().slice(0, 10);


function setLocalstorage(toDisplay,boolFilter){
    if(localStorage.getItem("user")){
        let showDiv = document.querySelector("#show");
        showDiv.innerHTML = ""
        let arr =JSON.parse(localStorage.getItem('user'));
        if(boolFilter) {  arr = toDisplay};
        arr.forEach((user,id)=>{
            let newDiv = document.createElement("div");
            newDiv.setAttribute("class","newdata");
            
            let htmldata =
                        `<b>Tittle</b> :- <span>${user.title} </span>
                         <b> Date</b> :- <span>${user.date} </span>
                         <button id ="btnEdit" onClick='onEdit(${id})'><b>Edit</b> <i class="bi bi-pencil-square"></i></button>
                         <button onClick='onDelete(${id})' ><b>Delete </b><i class="bi bi-trash"></i> </button>          
                        `;
                newDiv.insertAdjacentHTML("afterbegin",htmldata);
                showDiv.insertAdjacentElement("afterbegin",newDiv)
        })
    }else{
        let arr = []
        let arrData ={
            title : "",
            date : ""
        }
        arr.push(arrData)
        localStorage.setItem("user",JSON.stringify(arr))
        alert("Data pushed")
    }
}

setTimeout(() => {
    setLocalstorage()

}, 2);

//add function
submitBtn.addEventListener("click",(e)=>{
    e.preventDefault();
    let arr=JSON.parse(localStorage.getItem("user"));
    let title = document.querySelector("#title").value;
    let date = document.querySelector("#date").value;

    if(title.length <=0 && date.length <= 0){
        alert('enter something')
    }else if(title.length > 0 && date.length >0){
        let arrData = {
            title : title,
            date : date
        }
        // let arr = []
        arr.push(arrData);
        localStorage.setItem("user",JSON.stringify(arr))
        setLocalstorage();
    }else{
        alert("Enter something")
    }
})

//delete function

function onDelete(id){
    let arr =JSON.parse(localStorage.getItem("user"));
    let delteArr = [...arr];
    delteArr.splice(id,1)
    arr = [...delteArr]
    localStorage.setItem("user",JSON.stringify(arr))
    setLocalstorage()
}

//Edit function

function onEdit(id){
  let arr = JSON.parse(localStorage.getItem('user'));
  let title =document.querySelector("#title").value = arr[id].title;
  let date =document.querySelector("#date").value = arr[id].date;

  submitBtn.setAttribute("disabled",true)
  let editBtn = document.createElement("button");
  let form = document.querySelector("#form");
  let btnEdit =document.querySelectorAll("#btnEdit");
  editBtn.innerHTML ="Update";
  
  btnEdit.forEach((elements)=>{
      elements.setAttribute("disabled",true)
  })

  form.insertAdjacentElement("beforeend",editBtn)
  
  editBtn.addEventListener("click",(e)=>{
      e.preventDefault();
      let newtitle = document.querySelector("#title");
      let newdate = document.querySelector("#date");
      arr.splice(id,1, {title:newtitle.value,date:newdate.value})
      localStorage.setItem("user",JSON.stringify(arr))
      setLocalstorage();
      newtitle.value = ""
      newdate.value = ""
      form.removeChild(form.lastElementChild)
      submitBtn.removeAttribute("disabled")
    })
}


today.addEventListener("click",()=>{
    let data = [];
    data = JSON.parse(localStorage.getItem('user'));
    console.log(data);
    console.log("date", date);
    let filtered = [];
    filtered = data.filter(task=>task.date === date);
    console.log(filtered);
    setLocalstorage(filtered,true);
  })

  upcoming.addEventListener("click",()=>{
    let data = [];
    data = JSON.parse(localStorage.getItem('user'));
    console.log(data);
    console.log(date);
    let filtered = [];
    let current_datetime = new Date()
    let formatted_date = current_datetime.getFullYear() + "-0" + (current_datetime.getMonth() ) + "-" + (current_datetime.getDate()+2)
    console.log(formatted_date);
    filtered = data.filter(task=> {task.date < formatted_date});
     console.log(filtered);
     setLocalstorage(filtered,true);
  })









